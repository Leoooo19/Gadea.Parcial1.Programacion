package excepciones;

public class PlantaRepetidaException extends Exception {

    private static final String MESSAGE = "Ya existe una planta con ese nombre y ubicacion";

    public PlantaRepetidaException() {
        super(MESSAGE);
    }
}
