package model;

public abstract class Planta {

    private final String nombre;
    private final String ubicacion;
    private final String clima;

    public Planta(String nombre, String ubicacion, String clima) {
        this.nombre = nombre;
        this.ubicacion = ubicacion;
        this.clima = clima;
    }

    public String getNombre() {
        return nombre;
    }

    public String getUbicacion() {
        return ubicacion;
    }

    public String getClima() {
        return clima;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof Planta) {
            Planta otra = (Planta) obj;
            return this.nombre.equalsIgnoreCase(otra.nombre) && this.ubicacion.equalsIgnoreCase(otra.ubicacion);
        }
        return false;
    }

    @Override
    public int hashCode() {
        return nombre.toLowerCase().hashCode() + ubicacion.toLowerCase().hashCode();
    }

    @Override
    public String toString() {
        return "Nombre: " + nombre + ", Ubicacion: " + ubicacion + ", Clima: " + clima;
    }
}
