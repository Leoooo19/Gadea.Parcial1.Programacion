package model;

import excepciones.PlantaRepetidaException;
import interfaces.Podable;
import java.util.ArrayList;
import java.util.List;

public class JardinBotanico {

    private final List<Planta> plantas;

    public JardinBotanico() {
        plantas = new ArrayList<>();
    }

    public void agregarPlanta(Planta planta) throws PlantaRepetidaException {
        if (plantas.contains(planta)) {
            throw new PlantaRepetidaException();
        }
        plantas.add(planta);
    }

    public void mostrarPlantas() {
        for (Planta p : plantas) {
            System.out.println(p);
        }
    }

    public void podarPlantas() {
        for (Planta p : plantas) {
            if (p instanceof Podable podable) {
                podable.podar();
            } else if (p instanceof Flor flor) {
                flor.podar();
            
            }
        }
    }

    public void filtrarPorTemporadaFlorecimiento(Temporada temporada) {
        for (Planta p : plantas) {
            if (p instanceof Flor flor) {
                if (flor.getTemporada() == temporada) {
                    System.out.println(flor);
                }
            }
        }
    }
}
