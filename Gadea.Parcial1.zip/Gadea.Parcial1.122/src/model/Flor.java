package model;

import interfaces.Aromatica;

public class Flor extends Planta implements Aromatica {

    private final Temporada temporada;

    public Flor(String nombre, String ubicacion, String clima, Temporada temporada) {
        super(nombre, ubicacion, clima);
        this.temporada = temporada;
    }

    public Temporada getTemporada() {
        return temporada;
    }

    public void podar() {
        System.out.println("La flor " + getNombre() + " no se puede podar, ya que las flores no pueden ser podadas");
    }

    @Override
    public void desprenderAroma() {
        System.out.println("La flor " + getNombre() + " tiene un aroma apasionante ");
    }

    @Override
    public String toString() {
        return super.toString() + ", Temporada de florecimiento: " + temporada;
    }
}
