package model;

import interfaces.Podable;

public class Arbusto extends Planta implements Podable {

    public static final int MIN_DENSIDAD = 1;
    public static final int MAX_DENSIDAD = 10;
    private int densidad;

    public Arbusto(String nombre, String ubicacion, String clima, int densidad) {
        super(nombre, ubicacion, clima);
        if (validarDensidad(densidad)) {
            this.densidad = densidad;
        } else {
            throw new IllegalArgumentException("Densidad fuera de rango");
        }
    }

    public boolean validarDensidad(int densidad) {
        return densidad >= MIN_DENSIDAD && densidad <= MAX_DENSIDAD;
    }

    @Override
    public void podar() {
        System.out.println("Podando el arbusto: " + getNombre());
    }

    @Override
    public String toString() {
        return super.toString() + ", Densidad del follaje: " + densidad;
    }
}
