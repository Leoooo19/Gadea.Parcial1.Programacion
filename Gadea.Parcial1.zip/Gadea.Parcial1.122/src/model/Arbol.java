package model;

import interfaces.Aromatica;
import interfaces.Podable;

public class Arbol extends Planta implements Podable, Aromatica {

    private final int alturaMaxima;

    public Arbol(String nombre, String ubicacion, String clima, int alturaMaxima) {
        super(nombre, ubicacion, clima);
        this.alturaMaxima = alturaMaxima;
    }

    public String getNombre() {
        return super.getNombre();
    }

    @Override
    public void podar() {
        System.out.println("Podando el arbol: " + getNombre());
    }

    @Override
    public String toString() {
        return super.toString() + ", Altura maxima: " + alturaMaxima + "m";
    }

    @Override
    public void desprenderAroma() {
        System.out.println("El arbol " + getNombre() + " desprende un aroma fresco.");
    }
}
