package interfaces;

public interface Podable {

    void podar();
}
